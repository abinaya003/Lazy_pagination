# infinate-scroll-app
Implementing Infinite Scroll Pagination with React-Query v3

### To run the App
1. Clone the repository 
2. Install dependencies
```
  yarn
```
3. Run the app
```
  yarn dev
```
